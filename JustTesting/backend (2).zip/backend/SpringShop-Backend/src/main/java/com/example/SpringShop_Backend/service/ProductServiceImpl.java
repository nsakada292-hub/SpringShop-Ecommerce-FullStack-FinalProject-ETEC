package com.example.SpringShop_Backend.service;

import com.example.SpringShop_Backend.dto.request.ProductRequest;
import com.example.SpringShop_Backend.dto.response.CategoryResponse;
import com.example.SpringShop_Backend.dto.response.ProductResponse;
import com.example.SpringShop_Backend.entity.Category;
import com.example.SpringShop_Backend.entity.Product;
import com.example.SpringShop_Backend.exception.NotFoundException;
import com.example.SpringShop_Backend.repository.CategoryRepository;
import com.example.SpringShop_Backend.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    private static final String UPLOAD_DIR = "uploads/products";
    private static final String BASE_URL = "http://localhost:8080/uploads/products/";

    @Override
    public ProductResponse create(ProductRequest productRequest, MultipartFile file) throws IOException {

        Category category = categoryRepository.findById(productRequest.getCategoryId())
                .orElseThrow(() -> new NotFoundException("Category not found"));

        String imageUrl = saveFile(file);

        Product product = Product.builder()
                .productName(productRequest.getProductName())
                .description(productRequest.getDescription())
                .price(productRequest.getPrice())
                .stockQuantity(productRequest.getStockQuantity())
                .category(category)
                .size(productRequest.getSize())
                .color(productRequest.getColor())
                .material(productRequest.getMaterial())
                .image(imageUrl)
                .build();

        product = productRepository.save(product);

        return toResponse(product);
    }

    @Override
    public ProductResponse update(Long id, ProductRequest productRequest, MultipartFile file) throws IOException {

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Product not found"));

        Category category = categoryRepository.findById(productRequest.getCategoryId())
                .orElseThrow(() -> new NotFoundException("Category not found"));

        product.setProductName(productRequest.getProductName());
        product.setDescription(productRequest.getDescription());
        product.setPrice(productRequest.getPrice());
        product.setStockQuantity(productRequest.getStockQuantity());
        product.setCategory(category);
        product.setSize(productRequest.getSize());
        product.setColor(productRequest.getColor());
        product.setMaterial(productRequest.getMaterial());

        if (file != null && !file.isEmpty()) {
            String imageUrl = saveFile(file);
            product.setImage(imageUrl);
        }

        product = productRepository.save(product);

        return toResponse(product);
    }

    @Override
    public void delete(Long id) {

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Product not found"));

        productRepository.delete(product);
    }

    @Override
    public ProductResponse getById(Long id) {

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Product not found"));

        return toResponse(product);
    }

    @Override
    public List<ProductResponse> getAll() {

        List<Product> products = productRepository.findAll();
        List<ProductResponse> responses = new ArrayList<>();

        for (Product product : products) {
            responses.add(toResponse(product));
        }

        return responses;
    }

    @Override
    public List<ProductResponse> getByCategory(Long categoryId) {

        List<Product> products = productRepository.findByCategory_Id(categoryId);
        List<ProductResponse> responses = new ArrayList<>();

        for (Product product : products) {
            responses.add(toResponse(product));
        }

        return responses;
    }

    @Override
    public List<ProductResponse> search(String keyword) {

        List<Product> products = productRepository.findByProductNameContainingIgnoreCase(keyword);
        List<ProductResponse> responses = new ArrayList<>();

        for (Product product : products) {
            responses.add(toResponse(product));
        }

        return responses;
    }

    private String saveFile(MultipartFile file) throws IOException {

        String fileName = file.getOriginalFilename();
        String savedName = UUID.randomUUID().toString() + "-" + fileName;

        Path path = Paths.get(UPLOAD_DIR);

        if (!Files.exists(path)) {
            Files.createDirectories(path);
        }

        Files.copy(file.getInputStream(), path.resolve(savedName));

        return BASE_URL + savedName;
    }

    private ProductResponse toResponse(Product product) {

        CategoryResponse categoryResponse = CategoryResponse.builder()
                .id(product.getCategory().getId())
                .categoryName(product.getCategory().getCategoryName())
                .build();

        return ProductResponse.builder()
                .id(product.getId())
                .productName(product.getProductName())
                .description(product.getDescription())
                .price(product.getPrice())
                .stockQuantity(product.getStockQuantity())
                .category(categoryResponse)
                .size(product.getSize())
                .color(product.getColor())
                .material(product.getMaterial())
                .image(product.getImage())
                .createdAt(product.getCreatedAt())
                .updatedAt(product.getUpdatedAt())
                .build();
    }
}