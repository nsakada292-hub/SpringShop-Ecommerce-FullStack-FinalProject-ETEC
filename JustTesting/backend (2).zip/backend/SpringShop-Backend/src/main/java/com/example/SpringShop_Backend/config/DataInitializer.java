package com.example.SpringShop_Backend.config;

import com.example.SpringShop_Backend.entity.User;
import com.example.SpringShop_Backend.enumm.Role;
import com.example.SpringShop_Backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        String adminEmail = "admin@springshop.com";

        userRepository.findByEmail(adminEmail).ifPresentOrElse(
            user -> {
                if (user.getRole() != Role.ADMIN) {
                    user.setRole(Role.ADMIN);
                    user.setPassword(passwordEncoder.encode("admin123"));
                    userRepository.save(user);
                    log.info("Existing user upgraded to ADMIN: {}", adminEmail);
                }
            },
            () -> {
                User admin = User.builder()
                        .name("System Administrator")
                        .email(adminEmail)
                        .password(passwordEncoder.encode("admin123"))
                        .role(Role.ADMIN)
                        .build();
                userRepository.save(admin);
                log.info("Admin user created: {} / admin123", adminEmail);
            }
        );
    }
}
