package com.example.SpringShop_Backend.service;

import com.example.SpringShop_Backend.dto.request.ChangePasswordRequest;
import com.example.SpringShop_Backend.dto.request.UserRegisterRequest;
import com.example.SpringShop_Backend.dto.request.UserUpdateRequest;
import com.example.SpringShop_Backend.dto.response.UserResponse;
import com.example.SpringShop_Backend.entity.User;
import com.example.SpringShop_Backend.enumm.Role;
import com.example.SpringShop_Backend.exception.BadRequestException;
import com.example.SpringShop_Backend.exception.NotFoundException;
import com.example.SpringShop_Backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserResponse register(UserRegisterRequest userRegisterRequest) {

        if (userRepository.existsByEmail(userRegisterRequest.getEmail())) {
            throw new BadRequestException("Email already in use");
        }

        User user = User.builder()
                .name(userRegisterRequest.getName())
                .email(userRegisterRequest.getEmail())
                .password(passwordEncoder.encode(userRegisterRequest.getPassword()))
                .role(Role.USER)
                .build();

        user = userRepository.save(user);

        return toResponse(user);
    }

    @Override
    public UserResponse getMyProfile() {

        User user = getCurrentUser();

        return toResponse(user);
    }

    @Override
    public UserResponse updateMyProfile(UserUpdateRequest userUpdateRequest) {

        User user = getCurrentUser();

        if (!user.getEmail().equals(userUpdateRequest.getEmail())
                && userRepository.existsByEmail(userUpdateRequest.getEmail())) {
            throw new BadRequestException("Email already in use");
        }

        user.setName(userUpdateRequest.getName());
        user.setEmail(userUpdateRequest.getEmail());

        user = userRepository.save(user);

        return toResponse(user);
    }

    @Override
    public void changePassword(ChangePasswordRequest changePasswordRequest) {

        User user = getCurrentUser();

        boolean matches = passwordEncoder.matches(
                changePasswordRequest.getCurrentPassword(),
                user.getPassword()
        );

        if (!matches) {
            throw new BadRequestException("Current password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(changePasswordRequest.getNewPassword()));

        userRepository.save(user);
    }

    @Override
    public UserResponse getById(Long id) {

        User user = userRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found"));

        return toResponse(user);
    }

    @Override
    public List<UserResponse> getAll() {

        List<User> users = userRepository.findAll();
        List<UserResponse> responses = new ArrayList<>();

        for (User user : users) {
            responses.add(toResponse(user));
        }

        return responses;
    }

    private User getCurrentUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        return userRepository.findByEmail(email)
                .orElseThrow(() -> new NotFoundException("User not found"));
    }

    private UserResponse toResponse(User user) {

        return UserResponse.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .build();
    }
}