package com.example.SpringShop_Backend.service;

import com.example.SpringShop_Backend.dto.request.ChangePasswordRequest;
import com.example.SpringShop_Backend.dto.request.UserRegisterRequest;
import com.example.SpringShop_Backend.dto.request.UserUpdateRequest;
import com.example.SpringShop_Backend.dto.response.UserResponse;

import java.util.List;

public interface UserService {

    UserResponse register(UserRegisterRequest userRegisterRequest);

    UserResponse getMyProfile();

    UserResponse updateMyProfile(UserUpdateRequest userUpdateRequest);

    void changePassword(ChangePasswordRequest changePasswordRequest);

    UserResponse getById(Long id);

    List<UserResponse> getAll();
}