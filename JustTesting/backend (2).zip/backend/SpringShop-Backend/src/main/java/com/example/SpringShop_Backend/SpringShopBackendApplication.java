package com.example.SpringShop_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringShopBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringShopBackendApplication.class, args);
	}

}
