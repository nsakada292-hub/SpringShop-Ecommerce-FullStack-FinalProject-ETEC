/**
 * authApi.js — maps to AuthController (/api/auth)
 *
 *   POST /api/auth/register   register(payload)
 *   POST /api/auth/login      login(payload)
 *
 * Both endpoints return an AuthResponse. This module assumes that response
 * contains the JWT under one of `token` / `accessToken` / `jwt` — whichever
 * field your AuthResponse actually uses will be picked up automatically.
 * The raw response is always returned too, so callers can read any other
 * fields (user id, role, etc.) your backend includes.
 */
import { apiPost, setToken, clearToken } from './apiClient.js';

function extractToken(authResponse) {
  if (!authResponse) return null;
  return authResponse.token || authResponse.accessToken || authResponse.jwt || null;
}

/** @param {{name?:string, username?:string, email:string, password:string}} payload */
export async function register(payload) {
  const res = await apiPost('/auth/register', payload, { auth: false });
  const token = extractToken(res);
  if (token) setToken(token);
  return res;
}

/** @param {{email:string, password:string}} payload */
export async function login(payload) {
  const res = await apiPost('/auth/login', payload, { auth: false });
  const token = extractToken(res);
  if (token) setToken(token);
  return res;
}

export function logout() {
  clearToken();
}

export { isLoggedIn } from './apiClient.js';