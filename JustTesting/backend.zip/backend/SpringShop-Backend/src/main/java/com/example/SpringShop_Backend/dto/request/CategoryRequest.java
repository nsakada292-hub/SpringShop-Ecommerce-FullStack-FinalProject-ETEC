package com.example.SpringShop_Backend.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CategoryRequest {
    private String categoryName;
    private Long parentCategoryId; // just the id, not the whole object
    private String description;
}
