package com.example.SpringShop_Backend.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class CategoryResponse {
    private Long id;
    private String categoryName;
    private Long parentCategoryId;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
