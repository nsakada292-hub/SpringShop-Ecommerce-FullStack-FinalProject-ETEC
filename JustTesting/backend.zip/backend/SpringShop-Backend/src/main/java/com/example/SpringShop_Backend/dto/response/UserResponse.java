package com.example.SpringShop_Backend.dto.response;

import com.example.SpringShop_Backend.enumm.Role;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {
    private Long id;
    private String name;
    private String email;
    private Role role;
}
