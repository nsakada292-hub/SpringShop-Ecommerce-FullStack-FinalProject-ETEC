package com.example.SpringShop_Backend.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReviewRequest {
    private Long productId;
    private Integer rating;
    private String comment;
}
