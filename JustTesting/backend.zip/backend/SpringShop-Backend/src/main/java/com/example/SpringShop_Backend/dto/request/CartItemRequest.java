package com.example.SpringShop_Backend.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CartItemRequest {
    private Long productId;
    private Integer quantity;
}
